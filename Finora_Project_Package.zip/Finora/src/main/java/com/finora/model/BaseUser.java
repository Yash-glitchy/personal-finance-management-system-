package com.finora.model;

import java.util.Locale;

public abstract class BaseUser {
    private final long id;
    private String name;
    private String email;
    private String preferredCurrency;
    private boolean active;

    protected BaseUser(long id, String name, String email, String preferredCurrency, boolean active) {
        this.id = id; this.name = name; this.email = email; this.preferredCurrency = preferredCurrency; this.active = active;
    }
    public long getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPreferredCurrency() { return preferredCurrency; }
    public boolean isActive() { return active; }
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email.toLowerCase(Locale.ROOT); }
    public void setPreferredCurrency(String currency) { this.preferredCurrency = currency; }
    public void setActive(boolean active) { this.active = active; }
    public abstract String getRole();
    public abstract boolean canManageUsers();
}
