package com.finora.model;

import java.math.BigDecimal;
import java.util.Map;

public record UserReport(String currency,Map<String,BigDecimal> categorySpend,BigDecimal income,
                         BigDecimal expenses,BigDecimal net,Map<String,BigDecimal> sixMonthNet) { }
