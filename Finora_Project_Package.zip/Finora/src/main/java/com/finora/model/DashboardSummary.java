package com.finora.model;

import java.math.BigDecimal;
import java.util.Map;

public record DashboardSummary(String currency, BigDecimal income, BigDecimal expenses, BigDecimal balance,
                               BigDecimal monthlyBudget, BigDecimal remainingBudget, BigDecimal goalSaved,
                               BigDecimal goalTarget, Map<String, BigDecimal> spendingByCategory,
                               java.util.List<FinancialTransaction> recentTransactions) { }
