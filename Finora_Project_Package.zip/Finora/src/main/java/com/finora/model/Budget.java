package com.finora.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public record Budget(long id, long userId, String name, String category, BigDecimal amount, String currency,
                     LocalDate startDate, LocalDate endDate) { }
