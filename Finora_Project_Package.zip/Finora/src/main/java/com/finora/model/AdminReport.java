package com.finora.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public record AdminReport(long totalUsers,long activeUsers,long transactionCount,long securityEventCount,
                          Map<String,BigDecimal> financialByCurrency,Map<String,Long> securityByType,
                          List<String[]> recentEvents) { }
