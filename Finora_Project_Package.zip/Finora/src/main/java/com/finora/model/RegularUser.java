package com.finora.model;

public final class RegularUser extends BaseUser {
    public RegularUser(long id, String name, String email, String currency, boolean active) { super(id, name, email, currency, active); }
    @Override public String getRole() { return "USER"; }
    @Override public boolean canManageUsers() { return false; }
}
