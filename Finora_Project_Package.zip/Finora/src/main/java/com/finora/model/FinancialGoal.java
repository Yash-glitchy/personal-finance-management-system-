package com.finora.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public record FinancialGoal(long id, long userId, String name, String description, BigDecimal target,
                            BigDecimal saved, String currency, LocalDate deadline, String status) { }
