package com.finora.model;

public final class Admin extends BaseUser {
    public Admin(long id, String name, String email, String currency, boolean active) { super(id, name, email, currency, active); }
    @Override public String getRole() { return "ADMIN"; }
    @Override public boolean canManageUsers() { return true; }
}
