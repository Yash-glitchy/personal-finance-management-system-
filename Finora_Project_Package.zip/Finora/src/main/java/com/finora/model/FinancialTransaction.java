package com.finora.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public record FinancialTransaction(long id, long userId, String description, BigDecimal amount, String currency,
                                   String category, LocalDate date, String type, String notes) { }
