package com.finora.ui;

import com.finora.exception.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.function.Consumer;
import java.util.function.Supplier;

final class SwingUi {
    static final Color BG=new Color(11,15,13), SIDEBAR=new Color(17,23,19), PANEL=new Color(23,30,25), PANEL2=new Color(29,38,32), GREEN=new Color(57,255,136), GREEN2=new Color(24,199,106), TEXT=new Color(245,247,245), MUTED=new Color(155,166,158), RED=new Color(255,119,119), AMBER=new Color(255,193,92), LINE=new Color(48,60,52);
    static final Font BODY=new Font("Segoe UI",Font.PLAIN,14), MEDIUM=new Font("Segoe UI",Font.BOLD,14), TITLE=new Font("Segoe UI",Font.BOLD,27);
    private SwingUi() { }
    static JPanel panel(LayoutManager layout){JPanel p=new JPanel(layout);p.setBackground(BG);return p;}
    static JLabel label(String text){JLabel l=new JLabel(text);l.setForeground(TEXT);l.setFont(BODY);return l;}
    static JLabel muted(String text){JLabel l=label(text);l.setForeground(MUTED);return l;}
    static JButton button(String text,boolean primary){JButton b=new JButton(text);b.setFont(MEDIUM);b.setFocusPainted(false);b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));b.setBorder(new EmptyBorder(10,15,10,15));b.setBackground(primary?GREEN2:PANEL2);b.setForeground(Color.BLACK);return b;}
    static JPanel card(){JPanel p=new JPanel();p.setBackground(PANEL);p.setBorder(new CompoundBorder(new LineBorder(LINE,1,true),new EmptyBorder(18,18,18,18)));return p;}
    static JLabel pageTitle(String text){JLabel l=label(text);l.setFont(TITLE);return l;}
    static DefaultTableModel model(String... columns){return new DefaultTableModel(columns,0){@Override public boolean isCellEditable(int row,int column){return false;}};}
    static JTable table(DefaultTableModel model){JTable t=new JTable(model);t.setRowHeight(34);t.setFont(BODY);t.setForeground(TEXT);t.setBackground(PANEL);t.setGridColor(LINE);t.setSelectionBackground(new Color(34,72,49));t.setSelectionForeground(TEXT);t.setFillsViewportHeight(true);t.setAutoCreateRowSorter(true);t.getTableHeader().setBackground(PANEL2);t.getTableHeader().setForeground(MUTED);t.getTableHeader().setFont(MEDIUM);return t;}
    static JScrollPane scroll(Component c){JScrollPane s=new JScrollPane(c);s.setBorder(new LineBorder(LINE));s.getViewport().setBackground(PANEL);return s;}
    static void error(Component owner,Throwable error){Throwable e=error;while(e.getCause()!=null&&!(e instanceof ValidationException)&&!(e instanceof AuthenticationException)&&!(e instanceof AuthorizationException)&&!(e instanceof com.finora.exception.DatabaseOperationException))e=e.getCause();String message=e.getMessage()==null?"The operation could not be completed.":e.getMessage();JOptionPane.showMessageDialog(owner,message,"Finora",JOptionPane.ERROR_MESSAGE);}
    static void info(Component owner,String message){JOptionPane.showMessageDialog(owner,message,"Finora",JOptionPane.INFORMATION_MESSAGE);}
    static <T> void background(Component owner,JLabel status,String activity,Supplier<T> task,Consumer<T> done){
        status.setText(activity);status.setForeground(AMBER);
        new SwingWorker<T,Void>(){@Override protected T doInBackground(){return task.get();}@Override protected void done(){try{T value=get();status.setText("Ready");status.setForeground(MUTED);done.accept(value);}catch(Exception ex){status.setText("Could not load");status.setForeground(RED);Throwable cause=ex.getCause()==null?ex:ex.getCause();error(owner,cause);}}}.execute();
    }
    static JPanel toolbar(){JPanel p=new JPanel(new FlowLayout(FlowLayout.LEFT,9,0));p.setBackground(BG);return p;}
    static void applyDialogDefaults(){UIManager.put("OptionPane.background",PANEL);UIManager.put("Panel.background",PANEL);UIManager.put("OptionPane.messageForeground",TEXT);UIManager.put("TextField.background",PANEL2);UIManager.put("TextField.foreground",TEXT);UIManager.put("ComboBox.background",PANEL2);UIManager.put("ComboBox.foreground",TEXT);}
}
