package com.finora.ui;

import com.finora.dao.*;
import com.finora.model.BaseUser;
import com.finora.service.*;
import javax.swing.*;
import java.awt.*;

public final class AppFrame extends JFrame {
    private final UserDAO users=new UserDAO();private final SettingsDAO settings=new SettingsDAO();private final SecurityLogDAO logs=new SecurityLogDAO();
    private final TransactionDAO transactions=new TransactionDAO();private final BudgetDAO budgets=new BudgetDAO();private final FinancialGoalDAO goals=new FinancialGoalDAO();
    private final DashboardService dashboard=new DashboardService(transactions,budgets,goals);
    private final AuthService auth=new AuthService(users,logs,settings);private final FinanceService finance=new FinanceService(transactions,budgets,goals,logs,dashboard,settings);
    private final AdminService admin=new AdminService(users,settings,logs);private final ReportService reports=new ReportService(users,transactions,logs);private final ProfileService profile=new ProfileService(users,settings,logs);
    private final CardLayout cards=new CardLayout();private final JPanel root=new JPanel(cards);private final AuthPanel authPanel;
    public AppFrame(){super("Finora | Personal Finance");SwingUi.applyDialogDefaults();setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);setMinimumSize(new Dimension(1040,680));setSize(1280,800);setLocationRelativeTo(null);getContentPane().setBackground(SwingUi.BG);root.setBackground(SwingUi.BG);authPanel=new AuthPanel(auth,settings,this::openWorkspace);root.add(authPanel,"auth");add(root);addWindowListener(new java.awt.event.WindowAdapter(){@Override public void windowClosing(java.awt.event.WindowEvent e){com.finora.database.DatabaseManager.shutdown();dispose();}});}
    private void openWorkspace(BaseUser user){for(Component c:root.getComponents())if(c instanceof WorkspacePanel)root.remove(c);root.add(new WorkspacePanel(user,finance,dashboard,admin,reports,profile,users,settings,logs,this::logout),"workspace");cards.show(root,"workspace");}
    private void logout(){cards.show(root,"auth");authPanel.reset();}
}
