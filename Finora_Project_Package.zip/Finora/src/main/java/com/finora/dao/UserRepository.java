package com.finora.dao;

import com.finora.model.BaseUser;
import java.util.List;
import java.util.Optional;

public interface UserRepository {
    Optional<BaseUser> findByEmail(String email);
    Optional<BaseUser> findById(long id);
    List<BaseUser> findAll();
    BaseUser create(String name, String email, String passwordHash, String role, String currency);
    void updateProfile(BaseUser user, String passwordHash);
    void updateAccount(long id, String name, String email, String role, boolean active, String currency);
    void delete(long id);
    long countActiveAdmins();
}
