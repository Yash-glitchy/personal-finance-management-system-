package com.finora.dao;

import com.finora.database.DatabaseManager;
import com.finora.exception.DatabaseOperationException;
import com.finora.model.Budget;
import java.sql.*;
import java.util.*;

public final class BudgetDAO {
    public List<Budget> findByUser(long userId){List<Budget> out=new ArrayList<>();try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM budgets WHERE user_id=? ORDER BY start_date DESC")){p.setLong(1,userId);try(ResultSet r=p.executeQuery()){while(r.next())out.add(map(r));}return out;}catch(SQLException ex){throw new DatabaseOperationException("Could not load budgets",ex);}}
    public Budget save(Budget b){String sql=b.id()==0?"INSERT INTO budgets(user_id,name,category,amount,currency_code,start_date,end_date) VALUES(?,?,?,?,?,?,?)":"UPDATE budgets SET name=?,category=?,amount=?,currency_code=?,start_date=?,end_date=? WHERE budget_id=? AND user_id=?";try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement(sql,b.id()==0?Statement.RETURN_GENERATED_KEYS:Statement.NO_GENERATED_KEYS)){if(b.id()==0){p.setLong(1,b.userId());fill(p,2,b);p.executeUpdate();try(ResultSet k=p.getGeneratedKeys()){if(k.next())return new Budget(k.getLong(1),b.userId(),b.name(),b.category(),b.amount(),b.currency(),b.startDate(),b.endDate());}}else{fill(p,1,b);p.setLong(7,b.id());p.setLong(8,b.userId());if(p.executeUpdate()!=1)throw new SQLException("Budget is missing or does not belong to this user");}return b;}catch(SQLException ex){throw new DatabaseOperationException("Could not save budget",ex);}}
    private void fill(PreparedStatement p,int i,Budget b)throws SQLException{p.setString(i,b.name());p.setString(i+1,b.category());p.setBigDecimal(i+2,b.amount());p.setString(i+3,b.currency());p.setDate(i+4,java.sql.Date.valueOf(b.startDate()));p.setDate(i+5,java.sql.Date.valueOf(b.endDate()));}
    public void delete(long id,long userId){try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM budgets WHERE budget_id=? AND user_id=?")){p.setLong(1,id);p.setLong(2,userId);if(p.executeUpdate()!=1)throw new SQLException("Budget is missing or does not belong to this user");}catch(SQLException ex){throw new DatabaseOperationException("Could not delete budget",ex);}}
    private Budget map(ResultSet r)throws SQLException{return new Budget(r.getLong("budget_id"),r.getLong("user_id"),r.getString("name"),r.getString("category"),r.getBigDecimal("amount"),r.getString("currency_code"),r.getDate("start_date").toLocalDate(),r.getDate("end_date").toLocalDate());}
}
