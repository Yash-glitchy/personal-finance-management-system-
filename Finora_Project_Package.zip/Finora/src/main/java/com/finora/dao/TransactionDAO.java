package com.finora.dao;

import com.finora.database.DatabaseManager;
import com.finora.exception.DatabaseOperationException;
import com.finora.model.FinancialTransaction;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;

public final class TransactionDAO {
    public List<FinancialTransaction> findByUser(long userId) {
        List<FinancialTransaction> rows=new ArrayList<>();
        try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM transactions WHERE user_id=? ORDER BY transaction_date DESC,transaction_id DESC")){p.setLong(1,userId);try(ResultSet r=p.executeQuery()){while(r.next())rows.add(map(r));}return rows;}
        catch(SQLException ex){throw new DatabaseOperationException("Could not load transactions",ex);}
    }
    public FinancialTransaction save(FinancialTransaction t) {
        String sql=t.id()==0?"INSERT INTO transactions(user_id,description,amount,currency_code,category,transaction_date,transaction_type,notes) VALUES(?,?,?,?,?,?,?,?)":"UPDATE transactions SET description=?,amount=?,currency_code=?,category=?,transaction_date=?,transaction_type=?,notes=? WHERE transaction_id=? AND user_id=?";
        try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement(sql,t.id()==0?Statement.RETURN_GENERATED_KEYS:Statement.NO_GENERATED_KEYS)){
            if(t.id()==0){p.setLong(1,t.userId());fill(p,2,t);p.executeUpdate();try(ResultSet k=p.getGeneratedKeys()){if(k.next())return new FinancialTransaction(k.getLong(1),t.userId(),t.description(),t.amount(),t.currency(),t.category(),t.date(),t.type(),t.notes());}}
            else{fill(p,1,t);p.setLong(8,t.id());p.setLong(9,t.userId());if(p.executeUpdate()!=1)throw new SQLException("Transaction is missing or belongs to another account");}
            return t;
        }catch(SQLException ex){throw new DatabaseOperationException("Could not save transaction",ex);}
    }
    private void fill(PreparedStatement p,int start,FinancialTransaction t)throws SQLException{p.setString(start,t.description());p.setBigDecimal(start+1,t.amount());p.setString(start+2,t.currency());p.setString(start+3,t.category());p.setDate(start+4,java.sql.Date.valueOf(t.date()));p.setString(start+5,t.type());p.setString(start+6,t.notes()==null?"":t.notes());}
    public void delete(long id,long userId){try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM transactions WHERE transaction_id=? AND user_id=?")){p.setLong(1,id);p.setLong(2,userId);if(p.executeUpdate()!=1)throw new SQLException("Transaction is missing or belongs to another account");}catch(SQLException ex){throw new DatabaseOperationException("Could not delete transaction",ex);}}
    public BigDecimal sum(long userId,String currency,String type,LocalDate from,LocalDate through){
        String sql="SELECT COALESCE(SUM(amount),0) FROM transactions WHERE user_id=? AND currency_code=? AND transaction_type=? AND transaction_date BETWEEN ? AND ?";
        try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement(sql)){p.setLong(1,userId);p.setString(2,currency);p.setString(3,type);p.setDate(4,java.sql.Date.valueOf(from));p.setDate(5,java.sql.Date.valueOf(through));try(ResultSet r=p.executeQuery()){r.next();return r.getBigDecimal(1);}}catch(SQLException ex){throw new DatabaseOperationException("Could not calculate transaction total",ex);}
    }
    public BigDecimal categorySpend(long userId,String currency,String category,LocalDate from,LocalDate through){
        try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE user_id=? AND currency_code=? AND category=? AND transaction_type='EXPENSE' AND transaction_date BETWEEN ? AND ?")){p.setLong(1,userId);p.setString(2,currency);p.setString(3,category);p.setDate(4,java.sql.Date.valueOf(from));p.setDate(5,java.sql.Date.valueOf(through));try(ResultSet r=p.executeQuery()){r.next();return r.getBigDecimal(1);}}catch(SQLException ex){throw new DatabaseOperationException("Could not calculate budget spending",ex);}
    }
    public Map<String,BigDecimal> categoryTotals(long userId,String currency,LocalDate from,LocalDate through){
        Map<String,BigDecimal> out=new LinkedHashMap<>();
        try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("SELECT category,SUM(amount) total FROM transactions WHERE user_id=? AND currency_code=? AND transaction_type='EXPENSE' AND transaction_date BETWEEN ? AND ? GROUP BY category ORDER BY total DESC")){p.setLong(1,userId);p.setString(2,currency);p.setDate(3,java.sql.Date.valueOf(from));p.setDate(4,java.sql.Date.valueOf(through));try(ResultSet r=p.executeQuery()){while(r.next())out.put(r.getString(1),r.getBigDecimal(2));}return out;}catch(SQLException ex){throw new DatabaseOperationException("Could not group spending",ex);}
    }
    public long countAll(){try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("SELECT COUNT(*) FROM transactions");ResultSet r=p.executeQuery()){r.next();return r.getLong(1);}catch(SQLException ex){throw new DatabaseOperationException("Could not count transactions",ex);}}
    public Map<String,BigDecimal> totalsByCurrency(){Map<String,BigDecimal> out=new TreeMap<>();try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("SELECT currency_code,SUM(CASE WHEN transaction_type='INCOME' THEN amount ELSE -amount END) total FROM transactions GROUP BY currency_code");ResultSet r=p.executeQuery()){while(r.next())out.put(r.getString(1),r.getBigDecimal(2));return out;}catch(SQLException ex){throw new DatabaseOperationException("Could not summarize financial activity",ex);}}
    private FinancialTransaction map(ResultSet r)throws SQLException{return new FinancialTransaction(r.getLong("transaction_id"),r.getLong("user_id"),r.getString("description"),r.getBigDecimal("amount"),r.getString("currency_code"),r.getString("category"),r.getDate("transaction_date").toLocalDate(),r.getString("transaction_type"),r.getString("notes"));}
}
