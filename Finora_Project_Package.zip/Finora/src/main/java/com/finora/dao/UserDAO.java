package com.finora.dao;

import com.finora.database.DatabaseManager;
import com.finora.exception.DatabaseOperationException;
import com.finora.model.*;
import java.sql.*;
import java.util.*;

public final class UserDAO implements UserRepository {
    @Override public Optional<BaseUser> findByEmail(String email) { return one("SELECT * FROM users WHERE LOWER(email)=LOWER(?)", email); }
    @Override public Optional<BaseUser> findById(long id) { return one("SELECT * FROM users WHERE user_id=?", id); }
    private Optional<BaseUser> one(String sql, Object arg) {
        try (Connection c=DatabaseManager.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
            if (arg instanceof Long id) p.setLong(1,id); else p.setString(1,arg.toString());
            try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(map(r)):Optional.empty();}
        } catch(SQLException ex){throw new DatabaseOperationException("Could not read account",ex);}
    }
    @Override public List<BaseUser> findAll() {
        List<BaseUser> users=new ArrayList<>();
        try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM users ORDER BY role,name");ResultSet r=p.executeQuery()) { while(r.next()) users.add(map(r)); return users; }
        catch(SQLException ex){throw new DatabaseOperationException("Could not list accounts",ex);}
    }
    @Override public BaseUser create(String name,String email,String passwordHash,String role,String currency) {
        try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("INSERT INTO users(name,email,password_hash,role,preferred_currency) VALUES(?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS)) {
            p.setString(1,name);p.setString(2,email);p.setString(3,passwordHash);p.setString(4,role);p.setString(5,currency);p.executeUpdate();
            try(ResultSet k=p.getGeneratedKeys()){if(k.next())return findById(k.getLong(1)).orElseThrow();}
            throw new SQLException("No generated account ID returned");
        } catch(SQLException ex){throw new DatabaseOperationException("Could not create account. The email may already be registered.",ex);}
    }
    @Override public void updateProfile(BaseUser user,String passwordHash) {
        String sql=passwordHash==null?"UPDATE users SET name=?,email=?,preferred_currency=? WHERE user_id=?":"UPDATE users SET name=?,email=?,preferred_currency=?,password_hash=? WHERE user_id=?";
        try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,user.getName());p.setString(2,user.getEmail());p.setString(3,user.getPreferredCurrency());
            if(passwordHash==null)p.setLong(4,user.getId());else{p.setString(4,passwordHash);p.setLong(5,user.getId());}
            p.executeUpdate();
        } catch(SQLException ex){throw new DatabaseOperationException("Could not update profile. The email may already be registered.",ex);}
    }
    @Override public void updateAccount(long id,String name,String email,String role,boolean active,String currency) {
        try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("UPDATE users SET name=?,email=?,role=?,status=?,preferred_currency=? WHERE user_id=?")) {
            p.setString(1,name);p.setString(2,email);p.setString(3,role);p.setString(4,active?"ACTIVE":"INACTIVE");p.setString(5,currency);p.setLong(6,id);p.executeUpdate();
        } catch(SQLException ex){throw new DatabaseOperationException("Could not update account. Check that the email is unique.",ex);}
    }
    @Override public void delete(long id) { try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM users WHERE user_id=?")){p.setLong(1,id);p.executeUpdate();}catch(SQLException ex){throw new DatabaseOperationException("Could not delete account",ex);} }
    @Override public long countActiveAdmins() { return count("SELECT COUNT(*) FROM users WHERE role='ADMIN' AND status='ACTIVE'"); }
    public long countAll(){return count("SELECT COUNT(*) FROM users");}
    public long countActive(){return count("SELECT COUNT(*) FROM users WHERE status='ACTIVE'");}
    private long count(String sql){try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement(sql);ResultSet r=p.executeQuery()){r.next();return r.getLong(1);}catch(SQLException ex){throw new DatabaseOperationException("Could not count accounts",ex);}}
    private BaseUser map(ResultSet r)throws SQLException {
        long id=r.getLong("user_id");String name=r.getString("name"),email=r.getString("email"),currency=r.getString("preferred_currency");boolean active=r.getString("status").equals("ACTIVE");
        return r.getString("role").equals("ADMIN")?new Admin(id,name,email,currency,active):new RegularUser(id,name,email,currency,active);
    }
    public String passwordHash(long id){try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("SELECT password_hash FROM users WHERE user_id=?")){p.setLong(1,id);try(ResultSet r=p.executeQuery()){return r.next()?r.getString(1):null;}}catch(SQLException ex){throw new DatabaseOperationException("Could not verify account",ex);}}
}
