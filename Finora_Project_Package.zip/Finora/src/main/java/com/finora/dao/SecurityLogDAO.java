package com.finora.dao;

import com.finora.database.DatabaseManager;
import com.finora.exception.DatabaseOperationException;
import java.sql.*;
import java.util.*;

public final class SecurityLogDAO {
    public void add(Long userId,String email,String event,String detail){try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("INSERT INTO security_logs(actor_user_id,actor_email,event_type,detail) VALUES(?,?,?,?)")){if(userId==null)p.setNull(1,Types.BIGINT);else p.setLong(1,userId);p.setString(2,email);p.setString(3,event);p.setString(4,detail);p.executeUpdate();}catch(SQLException ex){throw new DatabaseOperationException("Could not write security event",ex);}}
    public List<String[]> recent(int limit){List<String[]> out=new ArrayList<>();try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("SELECT actor_email,event_type,detail,created_at FROM security_logs ORDER BY created_at DESC,log_id DESC LIMIT ?")){p.setInt(1,limit);try(ResultSet r=p.executeQuery()){while(r.next())out.add(new String[]{r.getString(1),r.getString(2),r.getString(3),r.getTimestamp(4).toString()});}return out;}catch(SQLException ex){throw new DatabaseOperationException("Could not load security events",ex);}}
    public Map<String,Long> countsByEvent(){Map<String,Long> out=new TreeMap<>();try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("SELECT event_type,COUNT(*) FROM security_logs GROUP BY event_type ORDER BY event_type");ResultSet r=p.executeQuery()){while(r.next())out.put(r.getString(1),r.getLong(2));return out;}catch(SQLException ex){throw new DatabaseOperationException("Could not summarize security events",ex);}}
    public long count(){try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("SELECT COUNT(*) FROM security_logs");ResultSet r=p.executeQuery()){r.next();return r.getLong(1);}catch(SQLException ex){throw new DatabaseOperationException("Could not count security events",ex);}}
}
