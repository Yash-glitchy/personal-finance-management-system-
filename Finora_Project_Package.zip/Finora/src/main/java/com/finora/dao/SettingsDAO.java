package com.finora.dao;

import com.finora.database.DatabaseManager;
import com.finora.exception.DatabaseOperationException;
import java.sql.*;
import java.util.*;

public final class SettingsDAO {
    public String get(String key,String fallback){try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("SELECT setting_value FROM application_settings WHERE setting_key=?")){p.setString(1,key);try(ResultSet r=p.executeQuery()){return r.next()?r.getString(1):fallback;}}catch(SQLException ex){throw new DatabaseOperationException("Could not read application settings",ex);}}
    public void set(String key,String value){try(Connection c=DatabaseManager.getConnection();PreparedStatement p=c.prepareStatement("MERGE INTO application_settings(setting_key,setting_value,updated_at) KEY(setting_key) VALUES(?,?,CURRENT_TIMESTAMP)")){p.setString(1,key);p.setString(2,value);p.executeUpdate();}catch(SQLException ex){throw new DatabaseOperationException("Could not save application settings",ex);}}
    public List<String> supportedCurrencies(){String csv=get("supported_currencies","INR,USD,EUR,GBP,AED");return Arrays.stream(csv.split(",")).map(String::trim).filter(s->!s.isBlank()).distinct().toList();}
}
