package com.finora.config;

import java.util.List;
import java.util.Map;

public final class AppConfig {
    public static final String APP_NAME = "Finora";
    public static final String JDBC_URL = "jdbc:h2:mem:finora;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE";
    public static final String JDBC_USER = "sa";
    public static final String JDBC_PASSWORD = "";
    public static final Map<String, String> CURRENCIES = Map.of(
            "INR", "₹", "USD", "$", "EUR", "€", "GBP", "£", "AED", "د.إ");
    public static final List<String> CATEGORIES = List.of("Food", "Transport", "Education", "Shopping",
            "Entertainment", "Healthcare", "Housing", "Travel", "Bills", "Salary", "Freelance Income", "Other");
    private AppConfig() { }
}
