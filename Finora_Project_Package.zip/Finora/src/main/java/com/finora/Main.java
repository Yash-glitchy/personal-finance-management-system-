package com.finora;

import com.finora.database.DatabaseManager;
import com.finora.ui.AppFrame;
import javax.swing.*;
import java.awt.*;

public final class Main {
    private Main() { }
    public static void main(String[] args) {
        DatabaseManager.initialize();
        Runtime.getRuntime().addShutdownHook(new Thread(DatabaseManager::shutdown,"finora-database-shutdown"));
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) { }
            AppFrame frame=new AppFrame();frame.setVisible(true);
        });
    }
}
