package com.finora.util;

import com.finora.config.AppConfig;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;

public final class MoneyFormatter {
    private MoneyFormatter() { }
    public static String format(BigDecimal value, String currency) {
        NumberFormat number = NumberFormat.getNumberInstance(Locale.forLanguageTag("en-" + localeCountry(currency)));
        number.setMinimumFractionDigits(2); number.setMaximumFractionDigits(2);
        return AppConfig.CURRENCIES.getOrDefault(currency, currency + " ") + number.format(value) + " " + currency;
    }
    private static String localeCountry(String currency) {
        return switch (currency) { case "INR" -> "IN"; case "USD" -> "US"; case "EUR" -> "DE"; case "GBP" -> "GB"; case "AED" -> "AE"; default -> "US"; };
    }
}
