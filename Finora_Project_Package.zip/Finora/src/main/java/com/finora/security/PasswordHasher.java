package com.finora.security;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.SecureRandom;
import java.util.Base64;

public final class PasswordHasher {
    private static final int ITERATIONS = 310_000;
    private static final int KEY_BITS = 256;
    private static final SecureRandom RANDOM = new SecureRandom();
    private PasswordHasher() { }

    public static String hash(String password) {
        byte[] salt = new byte[16]; RANDOM.nextBytes(salt);
        byte[] digest = derive(password.toCharArray(), salt, ITERATIONS);
        return "PBKDF2$" + ITERATIONS + "$" + Base64.getEncoder().encodeToString(salt) + "$" + Base64.getEncoder().encodeToString(digest);
    }

    public static boolean verify(String password, String encoded) {
        try {
            String[] pieces = encoded.split("\\$");
            if (pieces.length != 4 || !pieces[0].equals("PBKDF2")) return false;
            byte[] expected = Base64.getDecoder().decode(pieces[3]);
            byte[] actual = derive(password.toCharArray(), Base64.getDecoder().decode(pieces[2]), Integer.parseInt(pieces[1]));
            return java.security.MessageDigest.isEqual(expected, actual);
        } catch (RuntimeException ex) { return false; }
    }

    private static byte[] derive(char[] password, byte[] salt, int iterations) {
        PBEKeySpec spec = new PBEKeySpec(password, salt, iterations, KEY_BITS);
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
        catch (Exception ex) { throw new IllegalStateException("Password hashing is unavailable", ex); }
        finally { spec.clearPassword(); java.util.Arrays.fill(password, '\0'); }
    }
}
