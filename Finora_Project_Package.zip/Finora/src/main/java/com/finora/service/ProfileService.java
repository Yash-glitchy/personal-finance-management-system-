package com.finora.service;

import com.finora.dao.*;
import com.finora.exception.*;
import com.finora.model.BaseUser;
import com.finora.security.PasswordHasher;
import java.util.Locale;
import java.util.regex.Pattern;

public final class ProfileService {
    private static final Pattern EMAIL=Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private final UserDAO users;private final SettingsDAO settings;private final SecurityLogDAO logs;
    public ProfileService(UserDAO u,SettingsDAO s,SecurityLogDAO l){users=u;settings=s;logs=l;}
    public void update(BaseUser user,String name,String email,String currency,String currentPassword,String newPassword){
        String cleanName=AuthService.required(name,"Full name"),cleanEmail=AuthService.required(email,"Email").toLowerCase(Locale.ROOT);
        if(!EMAIL.matcher(cleanEmail).matches())throw new ValidationException("Enter a valid email address.");
        if(!settings.supportedCurrencies().contains(currency))throw new ValidationException("Choose a supported currency.");
        if(currentPassword==null||!PasswordHasher.verify(currentPassword,users.passwordHash(user.getId())))throw new AuthenticationException("Current password is incorrect.");
        if(!cleanEmail.equalsIgnoreCase(user.getEmail())&&users.findByEmail(cleanEmail).isPresent())throw new ValidationException("An account with that email already exists.");
        String newHash=null;if(newPassword!=null&&!newPassword.isBlank()){AuthService.validatePassword(newPassword,Integer.parseInt(settings.get("password_min_length","8")));newHash=PasswordHasher.hash(newPassword);}
        user.setName(cleanName);user.setEmail(cleanEmail);user.setPreferredCurrency(currency);users.updateProfile(user,newHash);
        logs.add(user.getId(),user.getEmail(),"PROFILE_UPDATED","Profile and preferences updated");
    }
}
