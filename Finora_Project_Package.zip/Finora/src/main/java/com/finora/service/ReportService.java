package com.finora.service;

import com.finora.dao.*;
import com.finora.model.*;
import java.math.BigDecimal;
import java.time.*;
import java.time.format.TextStyle;
import java.util.*;

public final class ReportService {
    private final UserDAO users;private final TransactionDAO transactions;private final SecurityLogDAO logs;
    public ReportService(UserDAO users,TransactionDAO transactions,SecurityLogDAO logs){this.users=users;this.transactions=transactions;this.logs=logs;}
    public AdminReport adminReport(BaseUser actor){if(actor==null||!actor.canManageUsers())throw new com.finora.exception.AuthorizationException("Administrator access is required.");return new AdminReport(users.countAll(),users.countActive(),transactions.countAll(),logs.count(),transactions.totalsByCurrency(),logs.countsByEvent(),logs.recent(25));}
    public UserReport userReport(BaseUser actor){if(actor==null||actor.canManageUsers())throw new com.finora.exception.AuthorizationException("Regular user access is required.");LocalDate today=LocalDate.now(),monthStart=today.withDayOfMonth(1),monthEnd=today.withDayOfMonth(today.lengthOfMonth());String curr=actor.getPreferredCurrency();List<FinancialTransaction> all=transactions.findByUser(actor.getId());
        Map<String,BigDecimal> categories=all.stream().filter(t->t.currency().equals(curr)&&t.type().equals("EXPENSE")&&!t.date().isBefore(monthStart)&&!t.date().isAfter(monthEnd)).collect(java.util.stream.Collectors.groupingBy(FinancialTransaction::category,LinkedHashMap::new,java.util.stream.Collectors.mapping(FinancialTransaction::amount,java.util.stream.Collectors.reducing(BigDecimal.ZERO,BigDecimal::add))));
        BigDecimal income=transactions.sum(actor.getId(),curr,"INCOME",monthStart,monthEnd),expense=transactions.sum(actor.getId(),curr,"EXPENSE",monthStart,monthEnd);
        Map<String,BigDecimal> monthly=new LinkedHashMap<>();for(int i=5;i>=0;i--){LocalDate first=today.minusMonths(i).withDayOfMonth(1);LocalDate last=first.withDayOfMonth(first.lengthOfMonth());String label=first.getMonth().getDisplayName(TextStyle.SHORT,Locale.ENGLISH)+" "+first.getYear();monthly.put(label,transactions.sum(actor.getId(),curr,"INCOME",first,last).subtract(transactions.sum(actor.getId(),curr,"EXPENSE",first,last)));}
        return new UserReport(curr,categories,income,expense,income.subtract(expense),monthly);
    }
}
