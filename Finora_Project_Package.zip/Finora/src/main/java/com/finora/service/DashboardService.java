package com.finora.service;

import com.finora.dao.*;
import com.finora.model.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

public final class DashboardService {
    private final TransactionDAO transactions;private final BudgetDAO budgets;private final FinancialGoalDAO goals;
    private final Map<Long,DashboardSummary> cache=new HashMap<>();
    public DashboardService(TransactionDAO t,BudgetDAO b,FinancialGoalDAO g){transactions=t;budgets=b;goals=g;}
    public DashboardSummary load(BaseUser user){
        synchronized(cache){DashboardSummary hit=cache.get(user.getId());if(hit!=null&&hit.currency().equals(user.getPreferredCurrency()))return hit;}
        LocalDate today=LocalDate.now(),monthStart=today.withDayOfMonth(1),monthEnd=today.withDayOfMonth(today.lengthOfMonth());String currency=user.getPreferredCurrency();
        BigDecimal income=transactions.sum(user.getId(),currency,"INCOME",LocalDate.of(1970,1,1),today),expense=transactions.sum(user.getId(),currency,"EXPENSE",LocalDate.of(1970,1,1),today);
        List<Budget> monthBudgets=budgets.findByUser(user.getId()).stream().filter(b->b.currency().equals(currency)&&!b.endDate().isBefore(monthStart)&&!b.startDate().isAfter(monthEnd)).toList();
        BigDecimal budget=monthBudgets.stream().map(Budget::amount).reduce(BigDecimal.ZERO,BigDecimal::add);
        BigDecimal budgetSpend=monthBudgets.stream().map(b->transactions.categorySpend(user.getId(),currency,b.category(),b.startDate(),b.endDate())).reduce(BigDecimal.ZERO,BigDecimal::add);
        BigDecimal goalSaved=BigDecimal.ZERO,goalTarget=BigDecimal.ZERO;for(FinancialGoal g:goals.findByUser(user.getId()))if(g.currency().equals(currency)&&!g.status().equals("COMPLETED")){goalSaved=goalSaved.add(g.saved());goalTarget=goalTarget.add(g.target());}
        List<FinancialTransaction> recent=transactions.findByUser(user.getId()).stream().limit(6).toList();
        DashboardSummary summary=new DashboardSummary(currency,income,expense,income.subtract(expense),budget,budget.subtract(budgetSpend),goalSaved,goalTarget,transactions.categoryTotals(user.getId(),currency,monthStart,monthEnd),recent);
        synchronized(cache){cache.put(user.getId(),summary);}return summary;
    }
    public void invalidate(long userId){synchronized(cache){cache.remove(userId);}}
}
