package com.finora.service;

import com.finora.config.AppConfig;
import com.finora.dao.*;
import com.finora.exception.*;
import com.finora.model.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

public final class FinanceService {
    private final TransactionDAO transactions;private final BudgetDAO budgets;private final FinancialGoalDAO goals;private final SecurityLogDAO logs;private final DashboardService dashboard;private final SettingsDAO settings;
    public FinanceService(TransactionDAO t,BudgetDAO b,FinancialGoalDAO g,SecurityLogDAO l,DashboardService d,SettingsDAO settings){transactions=t;budgets=b;goals=g;logs=l;dashboard=d;this.settings=settings;}
    private static void requireUser(BaseUser actor,long owner){if(actor==null||actor.canManageUsers()||actor.getId()!=owner)throw new AuthorizationException("You may only access your own financial records.");}
    public List<FinancialTransaction> transactions(BaseUser actor){if(actor.canManageUsers())throw new AuthorizationException("Administrative accounts do not have a personal transaction ledger.");return transactions.findByUser(actor.getId());}
    public FinancialTransaction saveTransaction(BaseUser actor,long id,String description,String amount,String category,String currency,LocalDate date,String type,String notes){
        if(actor.canManageUsers())throw new AuthorizationException("Administrative accounts do not have a personal transaction ledger.");
        String text=AuthService.required(description,"Description");String cat=AuthService.required(category,"Category");if(date==null)throw new ValidationException("Choose a transaction date.");
        BigDecimal value=parsePositive(amount,"Amount");if(!Set.of("INCOME","EXPENSE").contains(type))throw new ValidationException("Choose income or expense.");
        FinancialTransaction existing=id==0?null:transactions.findByUser(actor.getId()).stream().filter(t->t.id()==id).findFirst().orElseThrow(()->new AuthorizationException("Transaction is missing or belongs to another account."));validateCurrency(currency,existing==null?null:existing.currency());
        FinancialTransaction saved=transactions.save(new FinancialTransaction(id,actor.getId(),text,value,currency,cat,date,type,notes==null?"":notes.trim()));
        logs.add(actor.getId(),actor.getEmail(),id==0?"TRANSACTION_CREATED":"TRANSACTION_UPDATED","Transaction "+saved.id()+" saved");dashboard.invalidate(actor.getId());return saved;
    }
    public void deleteTransaction(BaseUser actor,long id){if(actor.canManageUsers())throw new AuthorizationException("Administrative accounts cannot delete personal transactions.");transactions.delete(id,actor.getId());logs.add(actor.getId(),actor.getEmail(),"TRANSACTION_DELETED","Transaction "+id+" deleted");dashboard.invalidate(actor.getId());}
    public List<Budget> budgets(BaseUser actor){requireRegular(actor);return budgets.findByUser(actor.getId());}
    public Budget saveBudget(BaseUser actor,long id,String name,String category,String amount,String currency,LocalDate start,LocalDate end){requireRegular(actor);String clean=AuthService.required(name,"Budget name"),cat=AuthService.required(category,"Category");BigDecimal value=parsePositive(amount,"Budget amount");if(start==null||end==null||end.isBefore(start))throw new ValidationException("Budget end date must be on or after its start date.");Budget existing=id==0?null:budgets.findByUser(actor.getId()).stream().filter(b->b.id()==id).findFirst().orElseThrow(()->new AuthorizationException("Budget is missing or belongs to another account."));validateCurrency(currency,existing==null?null:existing.currency());Budget b=budgets.save(new Budget(id,actor.getId(),clean,cat,value,currency,start,end));dashboard.invalidate(actor.getId());return b;}
    public BigDecimal budgetSpend(BaseUser actor,Budget b){requireUser(actor,b.userId());return transactions.categorySpend(actor.getId(),b.currency(),b.category(),b.startDate(),b.endDate());}
    public void deleteBudget(BaseUser actor,long id){requireRegular(actor);budgets.delete(id,actor.getId());dashboard.invalidate(actor.getId());}
    public List<FinancialGoal> goals(BaseUser actor){requireRegular(actor);return goals.findByUser(actor.getId()).stream().map(g->{FinancialGoal current=refreshStatus(g);if(!current.status().equals(g.status()))goals.updateStatus(g.id(),actor.getId(),current.status());return current;}).toList();}
    public FinancialGoal saveGoal(BaseUser actor,long id,String name,String description,String target,String saved,String currency,LocalDate deadline){requireRegular(actor);String clean=AuthService.required(name,"Goal name");BigDecimal targetValue=parsePositive(target,"Target amount");BigDecimal savedValue=parseNonNegative(saved,"Saved amount");if(deadline==null)throw new ValidationException("Choose a goal deadline.");FinancialGoal existing=id==0?null:goals.findByUser(actor.getId()).stream().filter(g->g.id()==id).findFirst().orElseThrow(()->new AuthorizationException("Goal is missing or belongs to another account."));validateCurrency(currency,existing==null?null:existing.currency());FinancialGoal g=refreshStatus(new FinancialGoal(id,actor.getId(),clean,description==null?"":description.trim(),targetValue,savedValue,currency,deadline,"IN_PROGRESS"));g=goals.save(g);dashboard.invalidate(actor.getId());return g;}
    public void deleteGoal(BaseUser actor,long id){requireRegular(actor);goals.delete(id,actor.getId());dashboard.invalidate(actor.getId());}
    private static FinancialGoal refreshStatus(FinancialGoal g){String status=g.saved().compareTo(g.target())>=0?"COMPLETED":(g.deadline().isBefore(LocalDate.now())?"OVERDUE":"IN_PROGRESS");return new FinancialGoal(g.id(),g.userId(),g.name(),g.description(),g.target(),g.saved(),g.currency(),g.deadline(),status);}
    private static void requireRegular(BaseUser actor){if(actor==null||actor.canManageUsers())throw new AuthorizationException("This feature is available to regular users.");}
    private void validateCurrency(String currency,String existingCurrency){if(currency==null||(!settings.supportedCurrencies().contains(currency)&&!currency.equals(existingCurrency)))throw new ValidationException("Choose a currently supported currency. Existing records keep their recorded currency.");}
    public static BigDecimal parsePositive(String raw,String label){try{BigDecimal v=new BigDecimal(raw.trim());if(v.signum()<=0)throw new ValidationException(label+" must be greater than zero.");return v;}catch(NumberFormatException|NullPointerException ex){throw new ValidationException("Enter a valid "+label.toLowerCase(Locale.ROOT)+".");}}
    public static BigDecimal parseNonNegative(String raw,String label){try{BigDecimal v=new BigDecimal(raw.trim());if(v.signum()<0)throw new ValidationException(label+" cannot be negative.");return v;}catch(NumberFormatException|NullPointerException ex){throw new ValidationException("Enter a valid "+label.toLowerCase(Locale.ROOT)+".");}}
}
