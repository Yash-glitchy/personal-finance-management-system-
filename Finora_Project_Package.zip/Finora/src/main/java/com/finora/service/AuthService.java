package com.finora.service;

import com.finora.config.AppConfig;
import com.finora.dao.*;
import com.finora.exception.*;
import com.finora.model.BaseUser;
import com.finora.security.PasswordHasher;
import java.util.Locale;
import java.util.regex.Pattern;

public final class AuthService {
    private static final Pattern EMAIL=Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private final UserRepository users;
    private final SecurityLogDAO logs;
    private final SettingsDAO settings;
    public AuthService(UserRepository users,SecurityLogDAO logs,SettingsDAO settings){this.users=users;this.logs=logs;this.settings=settings;}
    public BaseUser login(String email,String password){
        String normalized=email==null?"":email.trim().toLowerCase(Locale.ROOT);
        BaseUser user=users.findByEmail(normalized).orElse(null);
        if(user==null){logs.add(null,normalized,"LOGIN_FAILURE","Invalid sign-in credentials");throw new AuthenticationException("Email or password is incorrect.");}
        if(!user.isActive()){logs.add(user.getId(),user.getEmail(),"LOGIN_BLOCKED","Inactive account attempted sign-in");throw new AuthenticationException("This account is inactive. Contact an administrator.");}
        String hash=users instanceof UserDAO dao?dao.passwordHash(user.getId()):null;
        if(hash==null||!PasswordHasher.verify(password==null?"":password,hash)){logs.add(user.getId(),user.getEmail(),"LOGIN_FAILURE","Invalid sign-in credentials");throw new AuthenticationException("Email or password is incorrect.");}
        logs.add(user.getId(),user.getEmail(),"LOGIN_SUCCESS","Account signed in");return user;
    }
    public BaseUser register(String name,String email,String password,String currency){
        String cleanName=required(name,"Full name");String cleanEmail=required(email,"Email").toLowerCase(Locale.ROOT);
        if(!EMAIL.matcher(cleanEmail).matches())throw new ValidationException("Enter a valid email address.");
        int min=Integer.parseInt(settings.get("password_min_length","8"));validatePassword(password,min);
        if(users.findByEmail(cleanEmail).isPresent())throw new ValidationException("An account with that email already exists.");
        if(!settings.supportedCurrencies().contains(currency))throw new ValidationException("Choose a supported currency.");
        BaseUser user=users.create(cleanName,cleanEmail,PasswordHasher.hash(password),"USER",currency);
        logs.add(user.getId(),user.getEmail(),"USER_REGISTERED","New regular user account created");return user;
    }
    public static void validatePassword(String password,int min){if(password==null||password.length()<min)throw new ValidationException("Password must contain at least "+min+" characters.");if(password.chars().noneMatch(Character::isUpperCase)||password.chars().noneMatch(Character::isLowerCase)||password.chars().noneMatch(Character::isDigit))throw new ValidationException("Password must include an uppercase letter, lowercase letter, and number.");}
    public static String required(String value,String label){String clean=value==null?"":value.trim();if(clean.isEmpty())throw new ValidationException(label+" is required.");return clean;}
    public static void validateCurrency(String code){if(!AppConfig.CURRENCIES.containsKey(code))throw new ValidationException("Choose a supported currency.");}
}
