package com.finora.service;

import com.finora.dao.*;
import com.finora.database.DatabaseManager;
import com.finora.exception.AuthorizationException;
import com.finora.exception.ValidationException;
import com.finora.model.*;
import com.finora.util.MoneyFormatter;
import org.junit.jupiter.api.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class FinanceServiceTest {
    private UserDAO users;private AuthService auth;private FinanceService finance;private DashboardService dashboard;
    @BeforeEach void setUp(){DatabaseManager.initialize();users=new UserDAO();TransactionDAO tx=new TransactionDAO();BudgetDAO budgets=new BudgetDAO();FinancialGoalDAO goals=new FinancialGoalDAO();SecurityLogDAO logs=new SecurityLogDAO();SettingsDAO settings=new SettingsDAO();dashboard=new DashboardService(tx,budgets,goals);finance=new FinanceService(tx,budgets,goals,logs,dashboard,settings);auth=new AuthService(users,logs,settings);}
    @AfterEach void tearDown(){DatabaseManager.shutdown();}
    @Test void createsExpenseAndCalculatesBudgetFromActualExpenseRows(){BaseUser user=auth.login("user@finora.demo","User123!");LocalDate now=LocalDate.now();finance.saveTransaction(user,0,"Lunch","50.25","Food","INR",now,"EXPENSE","test entry");Budget budget=finance.saveBudget(user,0,"Food cap","Food","5000","INR",now.withDayOfMonth(1),now.withDayOfMonth(now.lengthOfMonth()));assertEquals(0,new BigDecimal("3500.75").compareTo(finance.budgetSpend(user,budget)));}
    @Test void goalStatusAndRemainingUseBigDecimal(){BaseUser user=auth.login("user@finora.demo","User123!");FinancialGoal goal=finance.saveGoal(user,0,"Laptop","","100000.00","100000.00","INR",LocalDate.now().plusDays(30));assertEquals("COMPLETED",goal.status());assertEquals(0,BigDecimal.ZERO.compareTo(goal.target().subtract(goal.saved()).max(BigDecimal.ZERO)));}
    @Test void ownershipChecksRejectAnotherUsersTransaction(){BaseUser user=auth.login("user@finora.demo","User123!");BaseUser other=auth.register("Other Person","other@example.test","Other123","INR");FinancialTransaction own=finance.saveTransaction(user,0,"Test","10","Food","INR",LocalDate.now(),"EXPENSE","");assertThrows(AuthorizationException.class,()->finance.saveTransaction(other,own.id(),"Change","10","Food","INR",LocalDate.now(),"EXPENSE",""));}
    @Test void invalidAmountsAreRejectedAndCurrencyFormattingIsExplicit(){assertThrows(ValidationException.class,()->FinanceService.parsePositive("0","Amount"));assertThrows(ValidationException.class,()->FinanceService.parsePositive("NaN","Amount"));assertTrue(MoneyFormatter.format(new BigDecimal("1234.5"),"USD").contains("USD"));}
    @Test void dashboardCacheSupportsConcurrentLoads(){BaseUser user=auth.login("user@finora.demo","User123!");java.util.concurrent.ExecutorService pool=java.util.concurrent.Executors.newFixedThreadPool(4);try{var tasks=java.util.stream.IntStream.range(0,8).mapToObj(i->pool.submit(()->dashboard.load(user))).toList();for(var task:tasks)assertNotNull(task.get().currency());}catch(Exception ex){fail(ex);}finally{pool.shutdownNow();}}
}
