package com.finora.service;

import com.finora.dao.*;
import com.finora.database.DatabaseManager;
import com.finora.exception.AuthorizationException;
import com.finora.model.BaseUser;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

class AuthorizationTest {
    private ReportService reports;private AdminService admin;
    @BeforeEach void setUp(){DatabaseManager.initialize();UserDAO users=new UserDAO();TransactionDAO tx=new TransactionDAO();SecurityLogDAO logs=new SecurityLogDAO();SettingsDAO settings=new SettingsDAO();reports=new ReportService(users,tx,logs);admin=new AdminService(users,settings,logs);}
    @AfterEach void tearDown(){DatabaseManager.shutdown();}
    @Test void regularAccountCannotReadAdminReportsOrListAllUsers(){BaseUser user=new AuthService(new UserDAO(),new SecurityLogDAO(),new SettingsDAO()).login("user@finora.demo","User123!");assertThrows(AuthorizationException.class,()->reports.adminReport(user));assertThrows(AuthorizationException.class,()->admin.users(user));}
}
