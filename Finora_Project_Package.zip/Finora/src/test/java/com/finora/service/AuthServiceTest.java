package com.finora.service;

import com.finora.dao.*;
import com.finora.database.DatabaseManager;
import com.finora.exception.AuthenticationException;
import com.finora.exception.ValidationException;
import com.finora.model.BaseUser;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

class AuthServiceTest {
    private AuthService auth;
    @BeforeEach void setUp(){DatabaseManager.initialize();auth=new AuthService(new UserDAO(),new SecurityLogDAO(),new SettingsDAO());}
    @AfterEach void tearDown(){DatabaseManager.shutdown();}
    @Test void demoLoginValidatesPasswordAndReturnsRole(){BaseUser user=auth.login("user@finora.demo","User123!");assertEquals("USER",user.getRole());assertFalse(user.canManageUsers());assertThrows(AuthenticationException.class,()->auth.login("user@finora.demo","wrong"));}
    @Test void registrationRejectsDuplicateEmailAndCreatesRegularUser(){BaseUser user=auth.register("Test Member","member@example.test","Member123","USD");assertEquals("USER",user.getRole());assertEquals("USD",user.getPreferredCurrency());assertThrows(ValidationException.class,()->auth.register("Second","member@example.test","Member123","INR"));}
}
