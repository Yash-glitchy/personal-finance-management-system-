# Finora — project review demo script

## Before the review

1. Install JDK 17+ and Maven 3.9+.
2. From this folder, run `mvn clean test` and keep the actual output for slide 11.
3. Run `mvn exec:java` or build and launch `java -jar target/finora-1.0.0.jar`.
4. Capture genuine screenshots from the running app and replace the slide 7 placeholders.
5. Use only the demonstration accounts and demo records.

## Suggested 6-minute walkthrough

### 1. Sign in as a regular user

- Email: `user@finora.demo`
- Password: `User123!`
- Point out that the initial dashboard figures come from seeded database rows, not UI constants.

### 2. Show a transaction change

- Open Transactions and create a small expense.
- Use a positive amount, a category, a transaction date, and the user's selected currency.
- Sort the JTable by amount or date and use the description/category/type/date filters.
- Explain that the DAO persists the row in H2 and the service invalidates the dashboard cache.

### 3. Show a budget calculation

- Open Budgets and inspect the Food budget.
- Explain that the amount spent comes from actual expense transactions with a matching user, category, currency, and date range.
- Mention that income rows do not count toward a budget.

### 4. Show goal progress and profile controls

- Open Goals and edit the saved amount to show progress and completion status.
- Open Profile, change a preference, and confirm that the app asks for the current password.
- Note that changing preferred currency does not convert old records.

### 5. Sign in as administrator

- Email: `admin@finora.demo`
- Password: `Admin123!`
- Show account search, role/status filters, and settings.
- Open Security to show login and account activity logs.
- Explain that a regular user cannot call admin operations through the service layer.

## GUVI rubric map

| Review area | Source example |
| --- | --- |
| OOP, inheritance, polymorphism | `model/BaseUser.java`, `model/Admin.java`, `model/RegularUser.java` |
| Interfaces and abstraction | `dao/UserRepository.java`, service/DAO separation |
| Exceptions | `exception/` package and form validation in `service/` |
| Collections, generics, streams | `DashboardService`, `ReportService`, typed DAO results |
| Multithreading | `SwingUi.background` and page `SwingWorker` tasks |
| Synchronization | `DashboardService` cache access and invalidation |
| JDBC and database operations | `database/DatabaseManager.java` and DAO classes |
| Authorization and data ownership | `service/FinanceService.java`, `service/AdminService.java` |

## Accurate statements for the review

- Passwords are stored as salted PBKDF2 hashes, not plaintext.
- The database stores records only in memory. Closing Finora discards them.
- Session timeout is a saved preference only; this version does not sign out automatically after idle time.
- Currency codes are retained on finance rows. The app does not convert currencies or fetch exchange rates.
- JUnit tests are present. Report passing status only after `mvn clean test` completes successfully.
